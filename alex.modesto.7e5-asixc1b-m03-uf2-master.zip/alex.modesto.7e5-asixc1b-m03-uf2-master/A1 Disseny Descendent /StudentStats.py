"""

    Àlex Modesto Mena
    ASIXc1B
    09/02/2022
    Després de fer un exàmen un professor vol veure l'estat general de la classe. Vol coneixer la nota mínima, la màxima i la mitjana dels seus alumnes.
    Fes un petit programa que li solucioni la tasca (les notes de l'exàmen no tenen decimals).
    IMPORTANT: no es poden fer servir les funcions de Python. Cal declarar funcions.

"""

