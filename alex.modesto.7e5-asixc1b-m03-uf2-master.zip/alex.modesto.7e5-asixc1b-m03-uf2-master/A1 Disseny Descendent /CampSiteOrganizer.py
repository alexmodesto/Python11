"""

    Àlex Modesto Mena
    ASIXc1B
    22 /02/2022
    Volem fer un petit programa per gestionar un càmping. Volem tenir controlat quantes parcel·les tenim plenes i quanta gent tenim.

"""

numero_persones = []
nom_persones = []

def 
