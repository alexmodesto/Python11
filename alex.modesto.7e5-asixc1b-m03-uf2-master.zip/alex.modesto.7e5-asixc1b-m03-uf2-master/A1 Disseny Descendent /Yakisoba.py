"""

    Àlex Modesto Mena
    ASIXc1B
    08/02/2022
    Prepara  fideus Yakisoba vegetals Baked by Lluís Bessa

"""

from time import sleep

from random import randint



def judici():

   global continuar2

   print("Estas a judici, el jutge està en contra teva, quina és la teva defensa?")

   sleep(3)

   print("1. No tenia diners")

   print("2. Em va donar un brot psicotic")

   valor = int(input("Opció? "))

   if valor == 1:

       print("T'envàs a la presó")

       print("G", end="")

       sleep(0.5)

       print("A", end="")

       sleep(0.5)

       print("M", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print(" ", end="")

       sleep(0.5)

       print("O", end="")

       sleep(0.5)

       print("V", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print("R")

       sleep(0.5)

       continuar2 ="Fail"

   elif valor == 2:

       print("El jutge s'apiada de tu i et demana que li cuinis")

       sleep(2)

       continuar2="Jutge"

   else:

       print("opció errònea")

       judici()

def judici2():

   global continuar3

   print("Estas a judici, el jutge està en contra teva, quina és la teva defensa?")

   sleep(3)

   print("1. No tenia diners")

   print("2. Em va donar un brot psicotic")

   valor = int(input("Opció? "))

   if valor == 1:

       print("T'envàs a la presó")

       print("G", end="")

       sleep(0.5)

       print("A", end="")

       sleep(0.5)

       print("M", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print(" ", end="")

       sleep(0.5)

       print("O", end="")

       sleep(0.5)

       print("V", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print("R")

       sleep(0.5)

       continuar3 ="Fail"

   elif valor == 2:

       print("El jutge s'apiada de tu, però davant la teva perillositat et tanca durant dos mesos a un centre")

       sleep(2)

       continuar3="centre"

   else:

       print("opció errònea")

       judici2()

def judici3():

   global continuar3

   print("Estas a judici, el jutge està en contra teva, quina és la teva defensa?")

   sleep(3)

   print("1. No tenia diners i el meu brot em va fer fer això")

   print("2. Et mataria a tu si pugués, dius mentres t'està afectant la teva demència")

   valor = int(input("Opció? "))

   if valor == 2:

       print("T'envàs a la presó")

       print("G", end="")

       sleep(0.5)

       print("A", end="")

       sleep(0.5)

       print("M", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print(" ", end="")

       sleep(0.5)

       print("O", end="")

       sleep(0.5)

       print("V", end="")

       sleep(0.5)

       print("E", end="")

       sleep(0.5)

       print("R")

       sleep(0.5)

       continuar3 = "Fail"

   elif valor == 1:

       print("El jutge et veu bastant serè però degut a la teva perillositat t'envia a un centre")

       sleep(2)

       continuar3 = "Centre"

   else:

       print("opció errònea")

       judici3()

def corre():

   valor = input("Correr o pagar? C/P")

   if valor.upper() == "C":

       pillar = randint(0, 1)

       if pillar == 0:

           print("T'has escapat")

           global continuar2

           continuar2=True

       else:

           print("T'han atrapat, tens judici el dia 25 de febrer")

           judici()

def centre():

   print("No has volgut pensar més, però al final et recuperes i et pots menjar els teus yakisoba")

   sleep(2)

   print("GG")





def recopilarIngredients():

   continuar = True

   while continuar:

       print("Comprar al supermercat")

       sleep(1)

       print("Disposar-los sobre el marbre")

       sleep(1)

       valor = input("Tens els ingredients Y/N ? ")

       if valor.upper() == 'Y':

           corre()

           continuar = False





def cuinarTallarinesNormal():

   continuar = True

   while continuar:

       print('Preparar aigua')

       sleep(1)

       print('Bullir tallarines')

       sleep(1)

       print('Escórrer tallarines')

       sleep(1)

       print('Deixar-les preparades')

       sleep(1)

       valor = input("Ho has aconseguit Y/N ? ")

       if valor.upper() == 'Y':

           continuar = False

def cuinarTallarinesJutge():

   continuar = True

   while continuar:

       print("Estas a casa del jutge")

       sleep(1)

       print("Mentres prepares l'aigua el jutge va a buscar licor, tens un moment i veus un anell d'or")

       sleep(1)

       valor=input("Robar o No R/N")

       if valor.upper()=="R":

           valor=randint(0,1)

           if valor==0:

               print("No s'en ha adonat")

               sleep(1)

               print('Bullir tallarines')

               sleep(1)

               print('Escórrer tallarines')

               sleep(1)

               print('Deixar-les preparades')

               sleep(1)

               valor = input("Ho has aconseguit Y/N ? ")

               if valor.upper() == 'Y':

                   continuar = False

           else:

               print("T'ha pillat i t'ho retreu")

               sleep(1)

               print("Que fas?")

               print("1. Demanar perdó")

               print("2. Dir que és cosa del teu brot psicòtic")

               print("3. En un atac de ràbia el mates")

               valor=int(input("Opció?"))

               if valor==1:

                   print("El jutge et pregunta perquè ho has fet, però s'apiada de tu i te'l regala")

                   continuar=False

               elif valor==2:

                   print("El jutge truca a la policia i vas a un judici amb un altre jutge")

                   judici2()

                   continuar=False

               elif valor==3:

                   print("El mates, et pillaràn? Tens opcions")

                   print("1. T'envàs a casa d'un amic")

                   print("2. Surts del país aquella mateixa nit")

                   print("3. T'envàs a casa perquè et penses que ha sigut una alucinació")

                   valor=int(input("Opció? "))

                   if valor==1:

                       print("Sembla ser que el teu amic és un petit delincuent, t'aconsegueix uns papers nous i t'aconsegueixes escapar a França")

                       exit()

                   elif valor==2:

                       print("Seràs molt violent, però no t'enteres de que ja t'estan buscant i t'atrapen")

                       judici3()

                       continuar=False

                   elif valor==3:

                       print("T'atrapen i vas a judici")

                       judici3()

                       continuar=False

                   else:

                       cuinarTallarinesJutge()



               else:

                   cuinarTallarinesJutge()



       else:

           print('Bullir tallarines')

           sleep(1)

           print('Escórrer tallarines')

           sleep(1)

           print('Deixar-les preparades')

           sleep(1)

           valor = input("Ho has aconseguit Y/N ? ")

           if valor.upper() == 'Y':

               continuar = False



def cuinarPastanagues():

   continuar = True

   while continuar:

       print('Tallar pastanagues')

       sleep(1)

       print('Fregir pastanagues')

       sleep(1)

       print('Deixar pastanagues preparades')

       sleep(1)

       valor = input("Ho has aconseguit Y/N ? ")

       if valor.upper() == 'Y':

           continuar = False





def cuinarCebes():

   continuar = True

   while continuar:

       print('Tallar cebes')

       sleep(1)

       print('Fregir cebes')

       sleep(1)

       print('Deixar cebes preparades')

       sleep(1)

       valor = input("Ho has aconseguit Y/N ? ")

       if valor.upper() == 'Y':

           continuar = False





def preparacióFinal():

   continuar = True

   while continuar:

       print('Barrejar ingredients amb salsa yakitori')

       sleep(1)

       print('Saltar ingredients')

       sleep(1)

       print('Deixar llest per servir')

       sleep(1)

       valor = input("Ho has aconseguit Y/N ? ")

       if valor.upper() == 'Y':

           print("Ja pots menjar!!!")

           continuar = False





# RECEPTA --------------------------------------------------------------

recopilarIngredients()

if continuar2=="Fail":

   print("YOU WENT TO JAIL")

   exit()

elif continuar2=="Jutge":

   cuinarTallarinesJutge()

   if continuar3=="Fail":

       print("YOU WENT TO JAIL")

       exit()

   elif continuar3=="centre":

       centre()

       print("FI DEL JOC")

   else:

       cuinarTallarinesNormal()

       cuinarPastanagues()

       cuinarCebes()

       preparacióFinal()

       print("FI DEL JOC")

else:

   cuinarTallarinesNormal()

   cuinarPastanagues()

   cuinarCebes()

   preparacióFinal()

   print("FI DEL JOC")
