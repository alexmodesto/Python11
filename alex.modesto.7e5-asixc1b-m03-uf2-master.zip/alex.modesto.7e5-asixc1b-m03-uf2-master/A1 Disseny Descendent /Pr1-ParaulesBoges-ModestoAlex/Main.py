"""

    Àlex Modesto Mena / Iker Mera Murillo
    ASIXc1B
    09/03/2022

"""

#pedir_frase
#separar_palabras
#mezclar letras palabra
    #comprobar que cumple requisitos (mas de 3 letras)
    #seleccionar primera y ultima letra
    #mezlcar medio
    #montar palabra final
#montar frase
#print frasse final


frase = []


def demanarFrase():
    frase_demanada = input("Frase: ")
    frase.append(frase_demanada)

def separarFrase():





