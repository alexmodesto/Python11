"""

    Àlex Modesto Mena
    ASIXc1B
    15/02/2022
    Volem fer un programa que analitzi els resultats d'un partit de bàsquet. Hem de tenir en compte que en un partit de bàsquet es poden fer 1, 2 o 3 punts.
    Donat els diferents resultats analitza que està passant.
    L'usuari introduirà primer el nom dels dos equips i després el resultat actual

"""
